// 정해진 숫자사이 짝수의 합
let num = 10
var ret = 0
